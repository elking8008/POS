# كورسات في البرمجة - Korsat X Parmaga
## تابعنا علي اليوتيوب - Follow us on YouTube
https://www.youtube.com/@korsatxparmaga

Follow these steps:
# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS
